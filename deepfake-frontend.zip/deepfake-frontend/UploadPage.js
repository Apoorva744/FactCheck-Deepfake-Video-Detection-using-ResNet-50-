// UploadPage.js - Fixed with proper navigation to Reports page
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './UploadPage.css';

const UploadPage = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [results, setResults] = useState(null);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      // Validate file type
      const validTypes = ['video/mp4', 'video/avi', 'video/mov', 'video/mkv', 'video/webm'];
      if (!validTypes.includes(file.type)) {
        setError('Please select a valid video file (MP4, AVI, MOV, MKV, WEBM)');
        return;
      }
      
      // Validate file size (max 100MB)
      const maxSize = 100 * 1024 * 1024; // 100MB
      if (file.size > maxSize) {
        setError('File too large. Maximum size is 100MB');
        return;
      }
      
      setSelectedFile(file);
      setError('');
      setResults(null);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) {
      handleFileSelect({ target: { files: [file] } });
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  const handleAnalyze = async () => {
    if (!selectedFile) {
      setError('Please select a video file first');
      return;
    }

    setIsAnalyzing(true);
    setError('');

    try {
      const formData = new FormData();
      formData.append('file', selectedFile);

      const response = await fetch('http://localhost:5000/api/predict', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });

      if (!response.ok) {
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();

      if (data.error) {
        setError(data.error);
      } else {
        setResults(data);
      }
    } catch (err) {
      console.error('Analysis error:', err);
      setError('Analysis failed. Please check if backend is running.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleReset = () => {
    setSelectedFile(null);
    setResults(null);
    setError('');
  };

  const handleGoToHistory = () => {
    navigate('/history');
  };

  // FIXED: Navigate to Reports page with data
  const handleViewDetailedReport = () => {
    navigate('/reports', {
      state: {
        result: results
      }
    });
  };

  const handleAnalyzeAnother = () => {
    handleReset();
  };

  // Show results screen
  if (results) {
    const isFake = results.label === 'FAKE';
    
    return (
      <div className="page-content upload-page">
        <div className="results-container">
          {/* Header with navigation */}
          <div className="results-header">
            <button className="back-btn" onClick={handleAnalyzeAnother}>
              ← Analyze Another Video
            </button>
            <button className="history-btn" onClick={handleGoToHistory}>
              View History →
            </button>
          </div>

          {/* Main Result */}
          <div className={`result-card ${isFake ? 'fake' : 'real'}`}>
            <div className="result-icon">
              {isFake ? '⚠️' : '✅'}
            </div>
            <h1 className="result-verdict">
              {isFake ? 'DEEPFAKE DETECTED' : 'VIDEO IS AUTHENTIC'}
            </h1>
            <div className="result-confidence">
              <div className="confidence-label">Confidence</div>
              <div className="confidence-value">
                {results.confidence_percent || Math.round((results.confidence || 0) * 100)}%
              </div>
            </div>
          </div>

          {/* Video Info */}
          <div className="info-card">
            <h3>Video Information</h3>
            <div className="info-grid">
              <div className="info-item">
                <span className="info-label">Filename:</span>
                <span className="info-value">{selectedFile.name}</span>
              </div>
              <div className="info-item">
                <span className="info-label">Report ID:</span>
                <span className="info-value">{results.reportId}</span>
              </div>
              <div className="info-item">
                <span className="info-label">Analysis Date:</span>
                <span className="info-value">{new Date().toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Detailed Analysis */}
          <div className="analysis-grid">
            <div className="analysis-card">
              <div className="analysis-icon">👤</div>
              <h4>Facial Analysis</h4>
              <p className="analysis-status">{results.facialStatus}</p>
              <p className="analysis-description">{results.facialDescription}</p>
            </div>

            <div className="analysis-card">
              <div className="analysis-icon">🎬</div>
              <h4>Audio-Visual Sync</h4>
              <p className="analysis-status">{results.audioVisualStatus}</p>
              <p className="analysis-description">{results.audioVisualDescription}</p>
            </div>

            <div className="analysis-card">
              <div className="analysis-icon">🔬</div>
              <h4>Technical Analysis</h4>
              <p className="analysis-status">{results.technicalStatus}</p>
              <p className="analysis-description">{results.technicalDescription}</p>
            </div>
          </div>

          {/* Action Buttons - FIXED: Added View Detailed Report button */}
          <div className="action-buttons">
            <button className="btn-secondary" onClick={handleAnalyzeAnother}>
              Analyze Another Video
            </button>
            <button className="btn-primary" onClick={handleViewDetailedReport}>
              View Detailed Report
            </button>
            <button className="btn-secondary" onClick={handleGoToHistory}>
              View All History
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Show upload screen
  return (
    <div className="page-content upload-page">
      <div className="upload-topbar">
        <button
          className="goBack"
          onClick={() => navigate("/dashboard")}
          aria-label="Go back"
        >
          ← Back
        </button>
      </div>

      <div className="upload-container">
        <div className="upload-header">
          <h1>Upload Video for Analysis</h1>
          <p>Upload a video to detect deepfake manipulations using AI</p>
        </div>
        
        {error && (
          <div className="error-banner">
            <span className="error-icon">⚠️</span>
            {error}
          </div>
        )}

        {/* Drag & Drop Area */}
        <div
          className={`upload-dropzone ${selectedFile ? 'has-file' : ''}`}
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onClick={() => document.getElementById('fileInput').click()}
        >
          <input
            type="file"
            id="fileInput"
            accept="video/*"
            onChange={handleFileSelect}
            style={{ display: 'none' }}
          />

          {selectedFile ? (
            <div className="file-preview">
              <div className="file-icon">🎬</div>
              <div className="file-info">
                <p className="file-name">{selectedFile.name}</p>
                <p className="file-size">
                  {(selectedFile.size / (1024 * 1024)).toFixed(2)} MB
                </p>
              </div>
              <button
                className="remove-file-btn"
                onClick={(e) => {
                  e.stopPropagation();
                  handleReset();
                }}
              >
                ✕
              </button>
            </div>
          ) : (
            <div className="upload-prompt">
              <div className="upload-icon">📤</div>
              <h3>Drag and drop your video here</h3>
              <p>or click to browse</p>
              <p className="upload-hint">Supported: MP4, AVI, MOV, MKV, WEBM (Max 100MB)</p>
            </div>
          )}
        </div>

        {/* Analyze Button */}
        <button
          className={`analyze-btn ${isAnalyzing ? 'analyzing' : ''}`}
          onClick={handleAnalyze}
          disabled={!selectedFile || isAnalyzing}
        >
          {isAnalyzing ? (
            <>
              <span className="spinner"></span>
              Analyzing Video...
            </>
          ) : (
            'Analyze Video'
          )}
        </button>

        {/* Info Section */}
        <div className="upload-info">
          <h3>How it works</h3>
          <div className="info-steps">
            <div className="step">
              <span className="step-number">1</span>
              <p>Upload your video file</p>
            </div>
            <div className="step">
              <span className="step-number">2</span>
              <p>AI analyzes facial features and patterns</p>
            </div>
            <div className="step">
              <span className="step-number">3</span>
              <p>Get detailed results in seconds</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UploadPage;