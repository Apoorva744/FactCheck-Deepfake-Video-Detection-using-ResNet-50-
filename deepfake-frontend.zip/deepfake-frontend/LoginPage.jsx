// src/pages/LoginPage.jsx (The correct and final version)

import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { login } from '../services/authService'; // Assuming this path is correct

function LoginPage({ onLogin }) { // CRITICAL: It must accept the onLogin prop
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState('');
    const [isSuccess, setIsSuccess] = useState(false);
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage('Authenticating...');
        setIsSuccess(false);
        
        const result = await login(username, password);

        if (result.success) {
            setMessage('Login successful!');
            setIsSuccess(true);
            
            // --- CRITICAL REDIRECTION LOGIC ---
            onLogin();           // 1. Tell App.js the user is logged in (updates global state)
            navigate('/upload'); // 2. YES, this is the line that directs to the upload page
            // ----------------------------------
            
        } else {
            setMessage('Error: ' + result.message);
            setIsSuccess(false);
        }
    };

    return (
        <div className="auth-container">
            <h2>Login</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} required />
                <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required />
                <button type="submit">Login</button>
                <p className="auth-message" style={{ color: isSuccess ? 'green' : 'red' }}>{message}</p>
                <p>Don't have an account? <Link to="/register">Register here</Link></p>
            </form>
        </div>
    );
}

export default LoginPage;