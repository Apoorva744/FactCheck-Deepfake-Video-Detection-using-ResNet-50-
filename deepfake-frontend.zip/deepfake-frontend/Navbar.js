// Navbar.js - Main Sidebar Component
import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import './Navbar.css';

const Navbar = ({ username, onLogout }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);

  // Handle window resize for mobile detection
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 768);
      if (window.innerWidth > 768) {
        setIsMobileOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Close mobile menu when route changes
  useEffect(() => {
    if (isMobile) {
      setIsMobileOpen(false);
    }
  }, [location.pathname, isMobile]);

  const handleLogout = () => {
    if (onLogout) {
      onLogout();
    }
    navigate('/login');
  };

  const toggleMobileMenu = () => {
    setIsMobileOpen(!isMobileOpen);
  };

  const menuItems = [
    {
      path: '/dashboard',
      icon: '🏠',
      label: 'Home',
      description: 'Dashboard overview'
    },
    {
      path: '/upload',
      icon: '📤',
      label: 'Upload Video',
      description: 'Scan for deepfakes'
    },
    {
      path: '/history',
      icon: '📜',
      label: 'History',
      description: 'View past scans'
    },
    {
      path: '/reports',
      icon: '📊',
      label: 'Reports',
      description: 'Detailed analysis'
    },
    {
      path: '/settings',
      icon: '⚙️',
      label: 'Settings',
      description: 'Account settings'
    },
    {
      path: '/help',
      icon: '❓',
      label: 'Help',
      description: 'Get support'
    },
    {
      path: '/about',
      icon: 'ℹ️',
      label: 'About',
      description: 'About DeepDetect'
    }
  ];

  return (
    <>
      {/* Mobile Menu Toggle Button */}
      {isMobile && (
        <button 
          className="mobile-menu-toggle"
          onClick={toggleMobileMenu}
          aria-label="Toggle menu"
        >
          ☰
        </button>
      )}

      {/* Mobile Overlay */}
      {isMobile && isMobileOpen && (
        <div 
          className="navbar-overlay active" 
          onClick={toggleMobileMenu}
        />
      )}

      {/* Sidebar */}
      <div className={`navbar ${isCollapsed ? 'collapsed' : ''} ${isMobile && isMobileOpen ? 'mobile-open' : ''}`}>
        {/* Collapse/Expand Button - Always visible on desktop */}
        {!isMobile && (
          <button 
            className="collapse-btn" 
            onClick={() => setIsCollapsed(!isCollapsed)}
            title={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            aria-label={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            {isCollapsed ? '☰' : '←'}
          </button>
        )}

        {/* Sidebar Header */}
        <div className="navbar-header">
          <div className="logo-container">
            <div className="logo-icon">👁️</div>
            {!isCollapsed && <h2 className="logo-text">DeepDetect</h2>}
          </div>
        </div>

        {/* User Info */}
        {!isCollapsed && username && (
          <div className="user-info">
            <div className="user-avatar">{username.charAt(0).toUpperCase()}</div>
            <div className="user-details">
              <p className="user-name">{username}</p>
              <p className="user-status">Active</p>
            </div>
          </div>
        )}

        {/* Navigation Menu */}
        <nav className="navbar-nav">
          <ul className="nav-list">
            {menuItems.map((item) => (
              <li key={item.path}>
                <Link
                  to={item.path}
                  className={`nav-item ${location.pathname === item.path ? 'active' : ''}`}
                  title={isCollapsed ? item.label : ''}
                >
                  <span className="nav-icon">{item.icon}</span>
                  {!isCollapsed && (
                    <div className="nav-content">
                      <span className="nav-label">{item.label}</span>
                      <span className="nav-description">{item.description}</span>
                    </div>
                  )}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        {/* Sidebar Footer */}
        <div className="navbar-footer">
          <button 
            className="logout-btn" 
            onClick={handleLogout}
            title={isCollapsed ? 'Logout' : ''}
            aria-label="Logout"
          >
            <span className="logout-icon">🚪</span>
            {!isCollapsed && <span>Logout</span>}
          </button>
        </div>
      </div>
    </>
  );
};

export default Navbar;