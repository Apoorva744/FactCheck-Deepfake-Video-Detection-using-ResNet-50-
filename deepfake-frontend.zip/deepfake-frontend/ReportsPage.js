// ReportsPage.js - Confidence-Based Timeline (Shows peaks for FAKE only)

import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Legend,
} from 'chart.js';
import './ReportsPage.css';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Tooltip,
  Legend
);

const ReportsPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [reportData, setReportData] = useState(null);

  useEffect(() => {
    if (location.state && location.state.result) {
      setReportData(location.state.result);
    }
  }, [location.state]);

  if (!reportData) {
    return (
      <div className="reports-page-container">
        <h1>No Report Available</h1>
        <p>Please upload and scan a video to see a report.</p>
        <button 
          className="btn-primary" 
          onClick={() => navigate('/upload')}
          style={{ marginTop: '20px' }}
        >
          Upload Video
        </button>
      </div>
    );
  }

  const isFake = reportData.label === 'FAKE';
  const timelineData = reportData.timeline || [];
  
  // Get the backend's confidence score (0-100 scale)
  const backendConfidence = reportData.confidenceScore || (reportData.confidence || 0) * 100;
  
  // For FAKE videos: Scale timeline to show peaks reaching the confidence score
  // For REAL videos: Keep it flat/low
  const displayTimeline = timelineData.map((suspicionScore) => {
    if (isFake) {
      // Scale the suspicion score to reach the confidence score at peaks
      // This normalizes the timeline so the max value reaches the confidence score
      return Math.round((suspicionScore || 0) * 100);
    } else {
      // For real videos, show the actual low suspicion values
      return Math.round((suspicionScore || 0) * 100);
    }
  });
  
  // Normalize the timeline for FAKE videos so peaks reach confidence score
  let normalizedTimeline = displayTimeline;
  if (isFake && displayTimeline.length > 0) {
    const maxTimelineValue = Math.max(...displayTimeline);
    if (maxTimelineValue > 0) {
      // Scale all values so the peak matches the confidence score
      normalizedTimeline = displayTimeline.map(val => 
        Math.round((val / maxTimelineValue) * backendConfidence)
      );
    }
  }
  
  const dataLine = {
    labels: timelineData.map((_, i) => `${i * 10}s`),
    datasets: [
      {
        label: isFake ? 'Detection Confidence (%)' : 'Suspicion Level (%)',
        data: normalizedTimeline,
        fill: true,
        borderColor: isFake ? '#ff6b6b' : '#51cf66',
        backgroundColor: isFake ? 'rgba(255, 107, 107, 0.2)' : 'rgba(81, 207, 102, 0.2)',
        tension: 0.4,
        pointRadius: 4,
        pointHoverRadius: 6,
      },
    ],
  };

  const optionsLine = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { 
        display: true,
        labels: {
          color: '#b0b0d6',
          font: {
            size: 14
          }
        }
      },
      tooltip: {
        mode: 'index',
        intersect: false,
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        titleColor: '#fff',
        bodyColor: '#fff',
        borderColor: isFake ? '#ff6b6b' : '#51cf66',
        borderWidth: 1,
        callbacks: {
          label: function(context) {
            if (isFake) {
              return `Detection Confidence: ${context.parsed.y}%`;
            } else {
              return `Suspicion Level: ${context.parsed.y}%`;
            }
          }
        }
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 100,
        grid: { 
          color: '#3a3a5a',
          drawBorder: false
        },
        ticks: { 
          color: '#b0b0d6',
          callback: function(value) {
            return value + '%';
          }
        },
        title: {
          display: true,
          text: isFake ? 'Detection Confidence (%)' : 'Suspicion Level (%)',
          color: '#b0b0d6',
          font: {
            size: 14
          }
        }
      },
      x: {
        grid: { 
          color: '#3a3a5a',
          drawBorder: false
        },
        ticks: { 
          color: '#b0b0d6'
        },
        title: {
          display: true,
          text: 'Timeline',
          color: '#b0b0d6',
          font: {
            size: 14
          }
        }
      },
    },
  };

  const peakTimeValue = reportData.peakTime || 0;
  
  const confidenceLabel = isFake ? 'Detection Confidence' : 'Authenticity Confidence';
  
  return (
    <div className="reports-page-container">
      <div className="reports-header">
        <h1>Video Analysis Report</h1>
        <p className="report-id">Report ID: #{reportData.reportId || 'N/A'}</p>
      </div>

      {/* Quick Summary Banner */}
      <div className={`summary-banner ${isFake ? 'fake' : 'authentic'}`}>
        <div className="banner-icon">
          {isFake ? '⚠️' : '✅'}
        </div>
        <div className="banner-content">
          <h2>{isFake ? 'DEEPFAKE DETECTED' : 'VIDEO IS AUTHENTIC'}</h2>
          <p>{confidenceLabel}: <strong>{backendConfidence.toFixed(2)}%</strong></p>
        </div>
      </div>

      <div className="reports-grid-timeline">
        {/* Analysis Timeline - Show chart for both FAKE and REAL */}
        <div className="reports-card analysis-timeline-large">
          <h2>{isFake ? 'Deepfake Detection Timeline' : 'Authenticity Analysis Timeline'}</h2>
          {timelineData.length > 0 ? (
            <>
              <div className="line-chart-container-large">
                <Line data={dataLine} options={optionsLine} />
              </div>
              <div className="timeline-details">
                {isFake ? (
                  <>
                    <p className="timeline-highlight">
                      <span className="timeline-icon">📍</span>
                      Peak detection confidence of {backendConfidence.toFixed(2)}% reached at {peakTimeValue * 10}s mark
                    </p>
                    <p className="timeline-info">
                      The chart shows how the model's detection confidence evolved throughout the video. 
                      The peak at {peakTimeValue * 10}s indicates the strongest evidence of manipulation.
                    </p>
                  </>
                ) : (
                  <>
                    <p className="timeline-highlight">
                      <span className="timeline-icon">✓</span>
                      Consistent authenticity maintained across all frames
                    </p>
                    <p className="timeline-info">
                      The flat line indicates minimal suspicious activity detected. All frames scored well below 
                      the deepfake detection threshold, confirming video authenticity.
                    </p>
                  </>
                )}
              </div>
            </>
          ) : (
            <div className="no-timeline">
              <p>No timeline data available for this analysis.</p>
            </div>
          )}
        </div>

        {/* Key Findings */}
        <div className="reports-card finding-details">
          <h2>Key Findings</h2>
          <ul className="findings-list">
            <li>
              <div className="finding-header-group">
                <span className="finding-label">Facial Irregularities:</span>
                <span
                  className={`finding-status ${
                    reportData.facialStatus?.toLowerCase() || 'unknown'
                  }`}
                >
                  {reportData.facialStatus || 'N/A'}
                </span>
              </div>
              <span className="finding-description">
                {reportData.facialDescription || 'No details provided.'}
              </span>
            </li>
            <li>
              <div className="finding-header-group">
                <span className="finding-label">Audio-Visual Sync:</span>
                <span
                  className={`finding-status ${
                    reportData.audioVisualStatus?.toLowerCase() || 'unknown'
                  }`}
                >
                  {reportData.audioVisualStatus || 'N/A'}
                </span>
              </div>
              <span className="finding-description">
                {reportData.audioVisualDescription || 'No details provided.'}
              </span>
            </li>
            <li>
              <div className="finding-header-group">
                <span className="finding-label">Technical Artifacts:</span>
                <span
                  className={`finding-status ${
                    reportData.technicalStatus?.toLowerCase() || 'unknown'
                  }`}
                >
                  {reportData.technicalStatus || 'N/A'}
                </span>
              </div>
              <span className="finding-description">
                {reportData.technicalDescription || 'No details provided.'}
              </span>
            </li>
          </ul>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="report-actions">
        <button 
          className="btn-secondary" 
          onClick={() => navigate('/upload')}
        >
          Analyze Another Video
        </button>
        <button 
          className="btn-primary" 
          onClick={() => navigate('/history')}
        >
          View History
        </button>
      </div>
    </div>
  );
};

export default ReportsPage;