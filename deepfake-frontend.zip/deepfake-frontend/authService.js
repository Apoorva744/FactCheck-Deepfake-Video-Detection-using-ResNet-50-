// src/services/authService.js
const API_BASE_URL = 'http://127.0.0.1:5000'; // VERIFY THIS PORT

export const getToken = () => {
    // Returns the username from localStorage for UI display
    return localStorage.getItem('deepfake_username');
};

export const clearAuthData = () => {
    // 1. Clear local username
    localStorage.removeItem('deepfake_username');
    // 2. Call backend /logout to clear the secure session cookie
    fetch(`${API_BASE_URL}/logout`, { method: 'GET' }); 
};

// --- API Functions ---

export async function register(username, password) {
    const response = await fetch(`${API_BASE_URL}/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
    });
    const data = await response.json();
    return { success: response.ok, message: data.message || data.error };
}

export async function login(username, password) {
    const response = await fetch(`${API_BASE_URL}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
    });
    const data = await response.json();

    if (response.ok) {
        // CRITICAL: Save username for UI display
        localStorage.setItem('deepfake_username', data.username); 
        return { success: true, username: data.username };
    } else {
        return { success: false, message: data.error };
    }
}

export async function fetchHistory() {
    // The browser automatically sends the Flask session cookie
    const response = await fetch(`${API_BASE_URL}/history`); 
    
    if (response.status === 401) {
        clearAuthData();
        throw new Error("Unauthorized");
    }
    
    if (!response.ok) {
        throw new Error("Failed to fetch history data.");
    }
    
    return response.json();
}