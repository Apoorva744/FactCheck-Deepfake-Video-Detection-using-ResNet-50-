import React from 'react';
import './SettingsPage.css';

const SettingsPage = () => {
  return (
    <div className="settings-container">
      <div className="settings-header">
        <h1>Settings</h1>
      </div>
      <div className="settings-content">
        <div className="settings-sidebar">
          <ul>
            <li className="active">Profile</li>
            <li>Security</li>
            <li>Analysis Settings</li>
          </ul>
        </div>
        <div className="settings-main">
          <div className="settings-card">
            <h2>Profile Information</h2>
            <form className="settings-form">
              <div className="form-group">
                <label htmlFor="username">Username</label>
                <input type="text" id="username" placeholder="Your Username" />
              </div>
              <div className="form-group">
                <label htmlFor="email">Email Address</label>
                <input type="email" id="email" placeholder="youremail@example.com" />
              </div>
              <button type="submit" className="btn btn-primary">Save Changes</button>
            </form>
          </div>
          <div className="settings-card">
            <h2>Analysis Settings</h2>
            <div className="setting-item">
              <label htmlFor="sensitivity">Detection Sensitivity</label>
              <input type="range" id="sensitivity" min="0" max="100" defaultValue="75" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;