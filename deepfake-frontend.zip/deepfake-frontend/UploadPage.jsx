// src/pages/UploadPage.jsx (MODIFIED)
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; 
import { clearAuthData } from '../services/authService'; 

const API_BASE_URL = 'http://127.0.0.1:5000'; 

function UploadPage() {
    const [file, setFile] = useState(null);
    const [loading, setLoading] = useState(false);
    const [result, setResult] = useState(null);
    const [error, setError] = useState(null);
    
    const navigate = useNavigate(); 

    const handleFileChange = (e) => {
        setFile(e.target.files[0]);
        setResult(null); 
        setError(null);
    };

    const handleUpload = async (e) => {
        e.preventDefault();
        
        if (!file) {
            setError("Please select a video file to analyze.");
            return;
        }

        setLoading(true);
        setError(null);
        setResult(null);

        const formData = new FormData();
        formData.append('file', file);

        try {
            const response = await fetch(`${API_BASE_URL}/predict`, {
                method: 'POST',
                body: formData,
            });
            
            // --- CRITICAL SECURITY CHECK ---
            if (response.status === 401) {
                // Session expired/invalid -> clear local data and redirect
                alert("Session expired. Please log in again to continue scanning.");
                clearAuthData(); 
                navigate('/');   
                return;          
            }
            // -------------------------------

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || `Server error: ${response.status}`);
            }

            const data = await response.json();
            setResult(data);
            
        } catch (err) {
            console.error("Upload/Scan Failed:", err);
            if (err.message !== "Unauthorized") {
                 setError(err.message);
            }
        } finally {
            setLoading(false);
        }
    };
    
    const renderResults = () => {
        if (!result) return null;
        
        // Use result.suspicion or result.confidence for the decimal value (0 to 1)
        const isFake = result.suspicion >= 0.1; // Or based on your backend label
        const score = result.label && result.label.toUpperCase() === 'FAKE'; // Show suspicion score

        return (
            <div className={`results-panel ${isFake ? 'fake-result' : 'real-result'}`}>
                <h3>Analysis Report: {result.reportId}</h3>
                <p><strong>Final Prediction:</strong> 
                    <span style={{ color: isFake ? 'red' : 'green', fontWeight: 'bold' }}>
                        {isFake ? 'FAKE' : 'REAL'}
                    </span>
                </p>
                <p><strong>Suspicion Score:</strong> {score}%</p>
                
                <div className="status-details">
                    <p><strong>Facial Status:</strong> {result.facialStatus}</p>
                    <p><strong>Technical Status:</strong> {result.technicalStatus}</p>
                </div>
            </div>
        );
    };


    return (
        <div className="upload-page-container">
            <div className="upload-column">
                <h2>Deepfake Video Analyzer</h2>
                <p>Upload a video file to begin the analysis. Results will be saved to your history.</p>
                
                <form onSubmit={handleUpload} className="upload-form">
                    <input 
                        type="file" 
                        accept="video/*" 
                        onChange={handleFileChange} 
                        required 
                        disabled={loading}
                    />
                    <button type="submit" disabled={!file || loading}>
                        {loading ? 'Analyzing...' : 'Scan Video'}
                    </button>
                </form>

                {error && <p className="error-message">{error}</p>}
            </div>
            
            <div className="results-column">
                {loading && <p>Processing video. This may take a minute...</p>}
                {result && renderResults()}
                {!loading && !result && !error && <p className="info-message">Ready to scan your video.</p>}
            </div>
        </div>
    );
}

export default UploadPage;