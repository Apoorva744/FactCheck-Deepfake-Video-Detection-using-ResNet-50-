import React, { useState } from 'react';
import './HelpPage.css';

const faqData = [
  {
    question: "What is a deepfake?",
    answer: "A deepfake is a video or image created using artificial intelligence to replace a person's face or body with that of another. Our system is designed to detect the subtle, tell-tale signs of this manipulation."
  },
  {
    question: "How accurate is the DeepDetect model?",
    answer: "Our model is continuously trained on large, diverse datasets to achieve a high degree of accuracy. However, no model is 100% perfect, and results should always be considered alongside other evidence."
  },
  {
    question: "What types of videos can I upload?",
    answer: "You can upload videos in common formats like MP4, AVI, and MOV. For best results, we recommend using high-quality videos that are not heavily compressed."
  },
  {
    question: "How long does the analysis take?",
    answer: "The analysis time depends on the length and quality of the video. Typically, a 1-minute video takes between 5 to 10 minutes to process, depending on current server load."
  }
];

const HelpPage = () => {
  const [openIndex, setOpenIndex] = useState(null);

  const handleToggle = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="help-container">
      <div className="help-header">
        <h1>Help Center</h1>
        <p>Frequently Asked Questions</p>
        <div className="search-bar">
          <input type="text" placeholder="Search for answers..." />
          <button>Search</button>
        </div>
      </div>
      
      <div className="faq-list">
        {faqData.map((item, index) => (
          <div key={index} className="faq-item">
            <div className="faq-question" onClick={() => handleToggle(index)}>
              <h3>{item.question}</h3>
              <span className="toggle-icon">{openIndex === index ? '-' : '+'}</span>
            </div>
            {openIndex === index && (
              <div className="faq-answer">
                <p>{item.answer}</p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default HelpPage;