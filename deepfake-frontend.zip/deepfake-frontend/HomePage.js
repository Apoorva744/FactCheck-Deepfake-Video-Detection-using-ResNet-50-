import React from 'react';

const HomePage = () => {
  return (
    <div className="page-content" style={{ textAlign: 'center' }}>
      <h1>Welcome to Deepfake Detector</h1>
      <p>Your one-stop solution for detecting deepfake videos with high accuracy.</p>
    </div>
  );
};

export default HomePage;