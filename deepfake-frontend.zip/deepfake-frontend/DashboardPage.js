// DashboardPage.js - Dashboard Implementation Example
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './DashboardPage.css';

const DashboardPage = ({ username }) => {
  const [stats, setStats] = useState({
    totalScans: 0,
    fakeDetected: 0,
    realVideos: 0,
    recentScans: []
  });

  useEffect(() => {
    // Fetch dashboard stats
    fetchDashboardStats();
  }, []);

  const fetchDashboardStats = async () => {
    try {
      // You can create a new API endpoint for dashboard stats
      const response = await fetch('http://localhost:5000/api/history', {
        credentials: 'include'
      });
      const history = await response.json();
      
      const totalScans = history.length;
      const fakeDetected = history.filter(item => item.prediction === 'FAKE').length;
      const realVideos = history.filter(item => item.prediction === 'REAL').length;
      const recentScans = history.slice(0, 5);

      setStats({ totalScans, fakeDetected, realVideos, recentScans });
    } catch (error) {
      console.error('Failed to fetch dashboard stats:', error);
    }
  };

  return (
    <div className="page-content dashboard-page">
      {/* Welcome Header */}
      <div className="dashboard-header">
        <h1>Welcome back, {username}! 👋</h1>
        <p className="subtitle">Here's what's happening with your deepfake detection</p>
      </div>

      {/* Stats Cards */}
      <div className="stats-grid">
        <div className="stat-card total">
          <div className="stat-icon">📊</div>
          <div className="stat-content">
            <h3>Total Scans</h3>
            <p className="stat-number">{stats.totalScans}</p>
          </div>
        </div>

        <div className="stat-card fake">
          <div className="stat-icon">⚠️</div>
          <div className="stat-content">
            <h3>Fake Detected</h3>
            <p className="stat-number">{stats.fakeDetected}</p>
          </div>
        </div>

        <div className="stat-card real">
          <div className="stat-icon">✅</div>
          <div className="stat-content">
            <h3>Real Videos</h3>
            <p className="stat-number">{stats.realVideos}</p>
          </div>
        </div>

        <div className="stat-card accuracy">
          <div className="stat-icon">🎯</div>
          <div className="stat-content">
            <h3>Accuracy</h3>
            <p className="stat-number">
              {stats.totalScans > 0 
                ? `${((stats.fakeDetected + stats.realVideos) / stats.totalScans * 100).toFixed(1)}%`
                : 'N/A'
              }
            </p>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="quick-actions">
        <h2>Quick Actions</h2>
        <div className="action-grid">
          <Link to="/upload" className="action-card primary">
            <div className="action-icon">📤</div>
            <h3>Scan Video</h3>
            <p>Upload and analyze a new video</p>
          </Link>

          <Link to="/history" className="action-card secondary">
            <div className="action-icon">📜</div>
            <h3>View History</h3>
            <p>Check your past scans</p>
          </Link>

          <Link to="/reports" className="action-card tertiary">
            <div className="action-icon">📊</div>
            <h3>Reports</h3>
            <p>Detailed analysis reports</p>
          </Link>

          <Link to="/help" className="action-card quaternary">
            <div className="action-icon">❓</div>
            <h3>Get Help</h3>
            <p>Learn how to use DeepDetect</p>
          </Link>
        </div>
      </div>

      {/* Recent Activity */}
      {stats.recentScans.length > 0 && (
        <div className="recent-activity">
          <div className="section-header">
            <h2>Recent Activity</h2>
            <Link to="/history" className="view-all">View All →</Link>
          </div>
          <div className="newgrid">
          <div className="activity-list">
            {stats.recentScans.map((scan) => (
              <div key={scan.id} className="activity-item">
                <div className="activity-icon">
                  {scan.prediction === 'FAKE' ? '⚠️' : '✅'}
                </div>
                <div className="activity-details">
                  <h4>{scan.filename}</h4>
                  <p className="activity-meta">
                    {scan.prediction} • {(scan.confidence * 100).toFixed(1)}% confidence
                  </p>
                  <p className="activity-time">
                    {new Date(scan.uploaded_at).toLocaleString()}
                  </p>
                </div>
                <div className={`activity-badge ${scan.prediction.toLowerCase()}`}>
                  {scan.prediction}
                </div>
              </div>
            ))}
          </div>
        </div>
        </div>
      )}

      {/* Info Cards */}
      <div className="info-section">
        <div className="info-card">
          <h3>🔒 Privacy First</h3>
          <p>Your videos are processed securely and deleted immediately after analysis.</p>
        </div>
        <div className="info-card">
          <h3>⚡ Fast Processing</h3>
          <p>Advanced AI models analyze videos in seconds, not minutes.</p>
        </div>
        <div className="info-card">
          <h3>🎯 High Accuracy</h3>
          <p>ResNet50 + XGBoost ensemble for reliable deepfake detection.</p>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;