// src/pages/HistoryPage.jsx (NEW FILE)
import React, { useState, useEffect } from 'react';
import { fetchHistory } from '../services/authService';

function HistoryPage() {
    const [history, setHistory] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        async function loadHistory() {
            setLoading(true);
            try {
                const data = await fetchHistory();
                setHistory(data);
            } catch (err) {
                // If 401 occurs, fetchHistory clears the token and throws
                setError("Failed to load history data. You may need to log in again.");
            } finally {
                setLoading(false);
            }
        }
        loadHistory();
    }, []); 

    if (loading) return <p className="loading">Loading history...</p>;
    if (error) return <p className="error-message">{error}</p>;
    if (history.length === 0) return <p className="info-message">No video scan history found.</p>;

    return (
        <div className="history-container">
            <h2>Your Scan History</h2>
            <table className="history-table">
                <thead>
                    <tr>
                        <th>File Name</th>
                        <th>Result</th>
                        <th>Confidence</th>
                        <th>Date Scanned</th>
                    </tr>
                </thead>
                <tbody>
                    {history.map((item) => {
                        // Ensure item.confidence is a number
                        const confidence = (parseFloat(item.confidence) * 100).toFixed(2);
                        const isFake = item.prediction === 'FAKE';
                        return (
                            <tr key={item.id}>
                                <td>{item.filename}</td>
                                <td style={{ color: isFake ? '#d32f2f' : '#388e3c', fontWeight: 'bold' }}>
                                    {item.prediction}
                                </td>
                                <td>{confidence}%</td>
                                <td>{item.uploaded_at}</td>
                            </tr>
                        );
                    })}
                </tbody>
            </table>
        </div>
    );
}

export default HistoryPage;