// HistoryPage.js - Fixed to display uploaded videos
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './HistoryPage.css';

const HistoryPage = () => {
  const [history, setHistory] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [filter, setFilter] = useState('all'); // 'all', 'fake', 'real'
  const navigate = useNavigate();

  useEffect(() => {
    fetchHistory();
  }, []);

  const fetchHistory = async () => {
    setIsLoading(true);
    setError('');

    try {
      const response = await fetch('http://localhost:5000/api/history', {
        credentials: 'include',
      });

      if (!response.ok) {
        throw new Error('Failed to fetch history');
      }

      const data = await response.json();
      console.log('History data received:', data); // Debug log
      setHistory(data);
    } catch (err) {
      console.error('History fetch error:', err);
      setError('Failed to load history. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const filteredHistory = history.filter((item) => {
    if (filter === 'all') return true;
    if (filter === 'fake') return item.prediction === 'FAKE';
    if (filter === 'real') return item.prediction === 'REAL';
    return true;
  });

  const stats = {
    total: history.length,
    fake: history.filter((item) => item.prediction === 'FAKE').length,
    real: history.filter((item) => item.prediction === 'REAL').length,
  };

  if (isLoading) {
    return (
      <div className="page-content history-page">
        <div className="loading-container">
          <div className="spinner-large"></div>
          <p>Loading history...</p>
        </div>
      </div>
    );
  }

  return (
    
    <div className="page-content history-page">
      {/* Header */}
      
      <div className="history-header-row">
        <button
          className="goBack"
          onClick={() => navigate("/dashboard")}
          aria-label="Go back"
        >
          ← Back
        </button>
        <div className="history-title">
        
          <h1>Analysis History</h1>
          <p>View all your previous video analyses</p>
        </div>
        <button className="upload-new-btn" onClick={() => navigate('/upload')}>
          + Upload New Video
        </button>
      </div>

      {/* Stats Cards */}
      <div className="stats-row">
        <div className="stat-box total">
          <div className="stat-icon">📊</div>
          <div className="stat-content">
            <div className="stat-number">{stats.total}</div>
            <div className="stat-label">Total Scans</div>
          </div>
        </div>

        <div className="stat-box fake">
          <div className="stat-icon">⚠️</div>
          <div className="stat-content">
            <div className="stat-number">{stats.fake}</div>
            <div className="stat-label">Deepfakes Detected</div>
          </div>
        </div>

        <div className="stat-box real">
          <div className="stat-icon">✅</div>
          <div className="stat-content">
            <div className="stat-number">{stats.real}</div>
            <div className="stat-label">Authentic Videos</div>
          </div>
        </div>
      </div>

      {/* Filter Buttons */}
      <div className="filter-bar">
        <button
          className={`filter-btn ${filter === 'all' ? 'active' : ''}`}
          onClick={() => setFilter('all')}
        >
          All ({stats.total})
        </button>
        <button
          className={`filter-btn ${filter === 'fake' ? 'active' : ''}`}
          onClick={() => setFilter('fake')}
        >
          Deepfakes ({stats.fake})
        </button>
        <button
          className={`filter-btn ${filter === 'real' ? 'active' : ''}`}
          onClick={() => setFilter('real')}
        >
          Authentic ({stats.real})
        </button>
        <button className="refresh-btn" onClick={fetchHistory} title="Refresh">
          🔄
        </button>
      </div>

      {/* Error Message */}
      {error && (
        <div className="error-message">
          <span>⚠️</span> {error}
        </div>
      )}

      {/* History List */}
      {filteredHistory.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">📹</div>
          <h3>No videos found</h3>
          <p>
            {filter === 'all'
              ? 'Upload your first video to get started!'
              : `No ${filter} videos found. Try a different filter.`}
          </p>
          <button className="btn-primary" onClick={() => navigate('/upload')}>
            Upload Video
          </button>
        </div>
      ) : (
        <div className="history-table-container">
          <table className="history-table">
            <thead>
              <tr>
                <th>Filename</th>
                <th>Result</th>
                <th>Confidence</th>
                <th>Date & Time</th>
              </tr>
            </thead>
            <tbody>
              {filteredHistory.map((item) => (
                <tr key={item.id} className="history-row">
                  <td className="filename-cell">
                    <div className="file-icon">🎬</div>
                    <span>{item.filename}</span>
                  </td>
                  <td>
                    <span className={`badge ${item.prediction.toLowerCase()}`}>
                      {item.prediction === 'FAKE' ? '⚠️ FAKE' : '✅ REAL'}
                    </span>
                  </td>
                  <td className="confidence-cell">
                    <div className="confidence-bar-container">
                      <div
                        className={`confidence-bar ${
                          item.prediction === 'FAKE' ? 'fake' : 'real'
                        }`}
                        style={{ width: `${item.confidence * 100}%` }}
                      ></div>
                    </div>
                    <span className="confidence-text">
                      {(item.confidence * 100).toFixed(1)}%
                    </span>
                  </td>
                  <td className="date-cell">
                    {new Date(item.uploaded_at).toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default HistoryPage;