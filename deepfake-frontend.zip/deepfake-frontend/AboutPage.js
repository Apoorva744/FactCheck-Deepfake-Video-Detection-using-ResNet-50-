import React from 'react';
import './AboutPage.css';

const AboutPage = () => {
  return (
    <div className="about-page">
      {/* Hero Section */}
      <section className="about-hero">
        <div className="hero-content">
          <h1 className="hero-title">About FactCheck</h1>
          <p className="hero-subtitle">
            Your trusted partner in the fight against digital manipulation
          </p>
        </div>
      </section>

      {/* Main Content */}
      <div className="about-container">
        
        {/* Who We Are */}
        <section className="about-section">
          <h2 className="section-title">Who We Are</h2>
          <p className="section-text">
            Welcome to <strong>FactCheck</strong> - your trusted partner in the fight against digital manipulation. 
            We are a cutting-edge deepfake detection platform powered by advanced artificial intelligence, 
            specifically designed to identify manipulated video content with exceptional accuracy.
          </p>
          <p className="section-text">
            In an era where seeing is no longer believing, FactCheck stands as a guardian of digital truth, 
            helping individuals and organizations distinguish between authentic and artificially altered videos.
          </p>
        </section>

        {/* Mission & Vision */}
        <section className="mission-vision-section">
          <div className="mv-card">
            <div className="mv-icon">🎯</div>
            <h3 className="mv-title">Our Mission</h3>
            <p className="mv-text">
              To detect manipulated video content and empower users with the truth. We believe that everyone 
              deserves access to authentic information.
            </p>
          </div>
          <div className="mv-card">
            <div className="mv-icon">🔮</div>
            <h3 className="mv-title">Our Vision</h3>
            <p className="mv-text">
              To protect digital authenticity and build a more trustworthy digital ecosystem where content 
              can be verified and trusted.
            </p>
          </div>
        </section>

        {/* How It Works */}
        <section className="about-section">
          <h2 className="section-title">How It Works</h2>
          <p className="section-text">
            FactCheck utilizes <strong>ResNet-50</strong>, a powerful deep learning architecture, combined 
            with advanced handcrafted feature extraction techniques to analyze videos frame-by-frame.
          </p>
          <div className="features-grid">
            <div className="feature-item">
              <div className="feature-icon">👤</div>
              <h4>Facial Features</h4>
              <p>Detecting inconsistencies in facial movements and expressions</p>
            </div>
            <div className="feature-item">
              <div className="feature-icon">🔍</div>
              <h4>Visual Artifacts</h4>
              <p>Identifying manipulation traces invisible to the human eye</p>
            </div>
            <div className="feature-item">
              <div className="feature-icon">⏱️</div>
              <h4>Temporal Coherence</h4>
              <p>Analyzing frame-to-frame consistency</p>
            </div>
            <div className="feature-item">
              <div className="feature-icon">📊</div>
              <h4>Frequency Analysis</h4>
              <p>Detecting digital fingerprints left by manipulation tools</p>
            </div>
          </div>
        </section>

        {/* What Makes Us Different */}
        <section className="about-section unique-section">
          <h2 className="section-title">What Makes Us Different</h2>
          <div className="unique-grid">
            <div className="unique-card">
              <div className="unique-icon">🎯</div>
              <h3>High Accuracy</h3>
              <p>
                Our ResNet-50 based model delivers exceptional detection accuracy, minimizing false 
                positives while catching even subtle manipulations.
              </p>
            </div>
            <div className="unique-card">
              <div className="unique-icon">⚡</div>
              <h3>Real-Time Detection</h3>
              <p>
                Get results in minutes, not hours. Our optimized pipeline processes videos quickly 
                without compromising accuracy.
              </p>
            </div>
            <div className="unique-card">
              <div className="unique-icon">📊</div>
              <h3>Transparent Results</h3>
              <p>
                We don't just tell you if a video is fake - we show you why with detailed analysis 
                reports and confidence scores.
              </p>
            </div>
            <div className="unique-card">
              <div className="unique-icon">🌐</div>
              <h3>Built for Everyone</h3>
              <p>
                Designed for social media platforms, journalists, content creators, and anyone 
                concerned about video authenticity.
              </p>
            </div>
          </div>
        </section>

        {/* Who We Serve */}
        <section className="about-section serve-section">
          <h2 className="section-title">Who We Serve</h2>
          <div className="serve-grid">
            <div className="serve-card">
              <h4>📱 Social Media Platforms</h4>
              <p>Maintain content integrity and protect users from misinformation with automated detection.</p>
            </div>
            <div className="serve-card">
              <h4>👥 General Public</h4>
              <p>Empower yourself to verify videos before sharing. Be a force for truth.</p>
            </div>
            <div className="serve-card">
              <h4>🎬 Content Creators</h4>
              <p>Protect your original work and reputation by proving the authenticity of your content.</p>
            </div>
            <div className="serve-card">
              <h4>📰 News Organizations</h4>
              <p>Verify sources and maintain journalistic integrity with reliable detection tools.</p>
            </div>
          </div>
        </section>

        {/* Technology */}
        <section className="about-section tech-section">
          <h2 className="section-title">The Technology Behind FactCheck</h2>
          <div className="tech-list">
            <div className="tech-item">
              <span className="tech-bullet">🧠</span>
              <div>
                <strong>Deep Learning:</strong> ResNet-50 neural network for feature extraction
              </div>
            </div>
            <div className="tech-item">
              <span className="tech-bullet">👁️</span>
              <div>
                <strong>Computer Vision:</strong> Advanced image processing techniques
              </div>
            </div>
            <div className="tech-item">
              <span className="tech-bullet">📡</span>
              <div>
                <strong>Signal Analysis:</strong> Frequency domain analysis to detect digital artifacts
              </div>
            </div>
            <div className="tech-item">
              <span className="tech-bullet">🔬</span>
              <div>
                <strong>Ensemble Methods:</strong> Machine Learning algorithms like XGBoost and Random Forest for robust results
              </div>
            </div>
          </div>
        </section>

        {/* Our Commitment */}
        <section className="about-section commitment-section">
          <h2 className="section-title">Our Commitment</h2>
          <div className="commitment-grid">
            <div className="commitment-item">
              <span className="commitment-icon">🚀</span>
              <p><strong>Continuous Innovation:</strong> Staying ahead of evolving deepfake technology</p>
            </div>
            <div className="commitment-item">
              <span className="commitment-icon">🔒</span>
              <p><strong>Privacy:</strong> Your videos are processed securely and not stored permanently</p>
            </div>
            <div className="commitment-item">
              <span className="commitment-icon">♿</span>
              <p><strong>Accessibility:</strong> Making advanced AI technology available to everyone</p>
            </div>
            <div className="commitment-item">
              <span className="commitment-icon">💎</span>
              <p><strong>Transparency:</strong> Providing clear, explainable results you can trust</p>
            </div>
            <div className="commitment-item">
              <span className="commitment-icon">📚</span>
              <p><strong>Education:</strong> Raising awareness about deepfakes and digital literacy</p>
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="cta-section">
          <h2 className="cta-title">Join Us in Protecting Digital Truth</h2>
          <p className="cta-text">
            In the digital age, authenticity matters more than ever. Every video you verify contributes 
            to a more trustworthy online ecosystem.
          </p>
          <p className="cta-tagline">
            <strong>Together, we can build a future where truth prevails over deception.</strong>
          </p>
        </section>

        {/* Footer Tagline */}
        <div className="about-footer">
          <p className="footer-tagline">FactCheck - Because Truth Matters</p>
        </div>

      </div>
    </div>
  );
};

export default AboutPage;