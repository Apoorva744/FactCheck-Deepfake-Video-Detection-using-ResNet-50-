#!/usr/bin/env python3
"""
predict.py - Deepfake Video Prediction with ResNet50 + Handcrafted Features
Modified to show confidence score (100 - fake_probability)
"""

import os
import tempfile
import numpy as np
import cv2
from pathlib import Path
from tensorflow.keras.applications.resnet50 import ResNet50, preprocess_input
from tensorflow.keras.models import Model
import joblib
import traceback
from skimage.feature import local_binary_pattern

# ============================================================
# CONFIGURATION
# ============================================================
EXPECTED_TOTAL = 2567
RESNET_FEATURES = 2048
HANDCRAFTED_FEATURES = EXPECTED_TOTAL - RESNET_FEATURES

FAKE_THRESHOLD = 0.01  # 1% threshold for fake detection sensitivity

# ============================================================
# LOAD MODELS
# ============================================================
try:
    base = ResNet50(weights='imagenet', include_top=False, pooling='avg')
    FEATURE_EXTRACTOR = Model(inputs=base.input, outputs=base.output)
    print("✅ ResNet50 loaded successfully")
except Exception as e:
    print("❌ Error loading ResNet50:", e)
    FEATURE_EXTRACTOR = None

CLASSIFIER = None
SCALER = None
try:
    CLASSIFIER = joblib.load("data/calibrated_classifier.pkl")
    SCALER = joblib.load("data/scaler.pkl")
    print("✅ Classifier & Scaler loaded successfully")
except Exception as e:
    print("⚠️ Warning: Failed to load classifier or scaler:", e)

# ============================================================
# FEATURE EXTRACTION HELPERS
# ============================================================
def ensure_uint8(img):
    if img is None:
        return np.zeros((224,224,3), dtype=np.uint8)
    if img.dtype == np.uint8:
        return img
    if np.issubdtype(img.dtype, np.floating) and img.max() <= 1.0:
        return (img * 255).astype(np.uint8)
    return img.astype(np.uint8)

def extract_multi_scale_lbp(image):
    image = ensure_uint8(image)
    gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    feats = []
    lbp1 = local_binary_pattern(gray, 8, 1, method='uniform'); h1,_ = np.histogram(lbp1.ravel(), bins=10, range=(0,10), density=True); feats.extend(h1.tolist())
    lbp2 = local_binary_pattern(gray, 16, 2, method='uniform'); h2,_ = np.histogram(lbp2.ravel(), bins=18, range=(0,18), density=True); feats.extend(h2.tolist())
    lbp3 = local_binary_pattern(gray, 24, 3, method='uniform'); h3,_ = np.histogram(lbp3.ravel(), bins=26, range=(0,26), density=True); feats.extend(h3.tolist())
    lbp4 = local_binary_pattern(gray, 16, 4, method='uniform'); h4,_ = np.histogram(lbp4.ravel(), bins=18, range=(0,18), density=True); feats.extend(h4.tolist())
    feats = np.array(feats, dtype=np.float32)
    if len(feats) < 260:
        feats = np.pad(feats, (0,260-len(feats)), mode='constant')
    return feats[:260]

def extract_edge_features(image):
    image = ensure_uint8(image)
    gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    sobelx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
    sobely = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
    mag = np.sqrt(sobelx**2 + sobely**2)
    hist_mag,_ = np.histogram(mag.ravel(), bins=50, range=(0, np.max(mag)+1e-5), density=True)
    dir_map = np.arctan2(sobely, sobelx)
    hist_dir,_ = np.histogram(dir_map.ravel(), bins=50, range=(-np.pi, np.pi), density=True)
    return np.concatenate([hist_mag, hist_dir])[:100].astype(np.float32)

def extract_frequency_features(image):
    image = ensure_uint8(image)
    gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    f = np.fft.fft2(gray); fshift = np.fft.fftshift(f)
    mag = np.abs(fshift); mag_log = np.log1p(mag)
    hist, _ = np.histogram(mag_log.ravel(), bins=100, range=(0, np.max(mag_log)+1e-6), density=True)
    return hist.astype(np.float32)

def extract_color_features(image):
    image = ensure_uint8(image)
    feats = []
    for ch in range(3):
        c = image[:,:,ch]
        feats.extend([
            np.mean(c), np.std(c), np.median(c),
            np.percentile(c,25), np.percentile(c,75),
            np.min(c), np.max(c)
        ])
        hist, _ = np.histogram(c, bins=10, range=(0,256), density=True)
        feats.extend(hist)
    feats.extend([0,0,0])  # placeholders for color correlation
    feats = np.array(feats, dtype=np.float32)
    return feats[:59]

def extract_all_handcrafted(image):
    lbp = extract_multi_scale_lbp(image)
    edge = extract_edge_features(image)
    freq = extract_frequency_features(image)
    color = extract_color_features(image)
    allf = np.concatenate([lbp, edge, freq, color])
    if allf.shape[0] < HANDCRAFTED_FEATURES:
        allf = np.pad(allf, (0, HANDCRAFTED_FEATURES - allf.shape[0]))
    return allf[:HANDCRAFTED_FEATURES].astype(np.float32)

# ============================================================
# MAIN PREDICTION FUNCTION
# ============================================================
def predict_video(file_or_path, max_frames=50):
    if FEATURE_EXTRACTOR is None:
        return {"error": "Feature extractor not loaded"}
    if CLASSIFIER is None or SCALER is None:
        return {"error": "Classifier or scaler not loaded"}

    # Handle upload or file path
    if not isinstance(file_or_path, (str, Path)):
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".mp4")
        file_or_path.save(tmp.name)
        video_path = tmp.name
    else:
        video_path = str(file_or_path)

    try:
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            return {"error": f"Could not open video {video_path}"}
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        if total_frames <= 0:
            cap.release()
            return {"error": "Invalid or empty video."}

        step = max(1, total_frames // max_frames)
        features = []

        for idx in range(0, total_frames, step):
            ret, frame = cap.read()
            if not ret or frame is None:
                break
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            resized = cv2.resize(frame, (224,224))
            arr = preprocess_input(np.expand_dims(resized.astype(np.float32), axis=0))
            deep = FEATURE_EXTRACTOR.predict(arr, verbose=0)[0]
            handcrafted = extract_all_handcrafted(rgb)
            combined = np.concatenate([deep, handcrafted])
            if len(combined) != EXPECTED_TOTAL:
                combined = np.pad(combined, (0, EXPECTED_TOTAL - len(combined)))[:EXPECTED_TOTAL]
            features.append(combined)

        cap.release()
        if not features:
            return {"error": "No frames processed successfully."}

        X = np.vstack(features)
        Xs = SCALER.transform(X)
        probs = CLASSIFIER.predict_proba(Xs)[:, 1]
        suspicion = float(np.mean(probs))  # avg fake probability
        timeline = probs.tolist()

        # ============================================
        # MODIFIED CONFIDENCE SCORE LOGIC
        # ============================================
        # Calculate confidence score as percentage (0-100 scale)
        fake_percentage = suspicion * 100  # Convert to percentage
        confidence_score = 100 - fake_percentage  # Invert to get confidence
        
        # Determine label based on threshold
        if suspicion > FAKE_THRESHOLD:
            label = "FAKE"
            display_score = confidence_score  # Show confidence score
        else:
            label = "REAL"
            display_score = confidence_score  # Show confidence score

        print(f"\n--- Prediction Summary ---")
        print(f"Confidence Score: {confidence_score:.2f}%")
        print(f"Threshold: {FAKE_THRESHOLD*100:.2f}%")
        print(f"Label: {label}")
        print(f"Display: {display_score:.2f}% {label}")
        print(f"---------------------------\n")

        return {
            "reportId": "RPT-" + os.path.basename(video_path),
            "label": label,
            "suspicion": suspicion,
            "confidence": display_score / 100,  # Return as 0-1 scale for consistency
            "confidenceScore": display_score,  # NEW: Confidence score 0-100 scale
            "timeline": timeline,
            "peakTime": int(np.argmax(timeline)) if len(timeline) else 0,
            "facialStatus": "Analyzed",
            "facialDescription": "Facial features processed.",
            "audioVisualStatus": "Analyzed",
            "audioVisualDescription": "Visual consistency checked.",
            "technicalStatus": "Analyzed",
            "technicalDescription": "ResNet50 + handcrafted (519) features applied."
        }

    except Exception as e:
        traceback.print_exc()
        return {"error": str(e)}
    finally:
        try:
            if not isinstance(file_or_path, (str, Path)) and os.path.exists(video_path):
                os.unlink(video_path)
        except Exception:
            pass